#!/bin/bash

# Flush existing rules
iptables -F

# Set default policy to DROP
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# Allow established connections
iptables -A INPUT -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT

# Allow loopback interface
iptables -A INPUT -i lo -j ACCEPT

# Allow incoming connections on specific ports
iptables -A INPUT -p tcp --dport 80 -j ACCEPT    # HTTP
iptables -A INPUT -p tcp --dport 443 -j ACCEPT   # HTTPS
iptables -A INPUT -p tcp --dport 22 -j ACCEPT    # SSH
iptables -A INPUT -p tcp --dport 21 -j ACCEPT    # FTP
iptables -A INPUT -p tcp --dport 25 -j ACCEPT    # SMTP
iptables -A INPUT -p udp --dport 53 -j ACCEPT    # DNS
iptables -A INPUT -p tcp --dport 110 -j ACCEPT   # POP3
iptables -A INPUT -p tcp --dport 143 -j ACCEPT   # IMAP
iptables -A INPUT -p tcp --dport 23 -j ACCEPT    # Telnet
iptables -A INPUT -p tcp --dport 3389 -j ACCEPT  # RDP
iptables -A INPUT -p tcp --dport 443 -j ACCEPT   # LDAPS
iptables -A INPUT -p udp --dport 69 -j ACCEPT    # TFTP
iptables -A INPUT -p tcp --dport 119 -j ACCEPT   # NNTP
iptables -A INPUT -p udp --dport 161 -j ACCEPT   # SNMP
iptables -A INPUT -p tcp --dport 389 -j ACCEPT   # LDAP
iptables -A INPUT -p tcp --dport 443 -j ACCEPT   # IKE
iptables -A INPUT -p tcp --dport 993 -j ACCEPT   # IMAPS
iptables -A INPUT -p tcp --dport 995 -j ACCEPT   # POP3S
iptables -A INPUT -p tcp --dport 1433 -j ACCEPT  # MSSQL
iptables -A INPUT -p tcp --dport 3306 -j ACCEPT  # MySQL
# Allow ICMP echo requests (ping)
iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT

# Allow ICMP echo replies
iptables -A INPUT -p icmp --icmp-type echo-reply -j ACCEPT

# Allow ICMP destination unreachable messages (optional, for diagnostic purposes)
iptables -A INPUT -p icmp --icmp-type destination-unreachable -j ACCEPT

# Save the rules
iptables-save > /etc/iptables/rules.v4

# Display the rules
iptables -L -v
