#!/bin/bash

# Define the password to be set
new_password="swaglikeohio1!"

# Loop through all users on the system and change their passwords
for user in $(cut -d: -f1 /etc/passwd)
do
    echo "Changing password for user: $user"
    echo "$user:$new_password" | chpasswd
done

echo "All user passwords changed to: $new_password"
