#!/bin/bash

# Iterate over all user directories in /home and include root
for user_home in /home/* /root; do
    # Check if the directory is a user's home directory
    if [ -d "$user_home" ]; then
        user=$(basename "$user_home")
        
        # Check if the user has a .bashrc file
        if [ -f "$user_home/.bashrc" ]; then
            # Add unset HISTFILE to the user's .bashrc file
            echo "unset HISTFILE" >> "$user_home/.bashrc"
            echo "Unset HISTFILE for user: $user"
        else
            echo "No .bashrc found for user: $user"
        fi
    fi
done

echo "Completed unsetting HISTFILE for all users including root."