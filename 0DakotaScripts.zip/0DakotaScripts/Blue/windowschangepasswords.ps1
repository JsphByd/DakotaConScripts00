# Define the new password
$newPassword = ConvertTo-SecureString -String "swaglikeohio1!" -AsPlainText -Force

# Get all user accounts
$users = Get-LocalUser

# Loop through each user and change their password
foreach ($user in $users) {
    # Change password for the user
    Set-LocalUser -Name $user.Name -Password $newPassword
}

Write-Host "Passwords changed for all users to 'swaglikeohio1!'"
