# Define the domain controller
$domainController = "YOUR_DOMAIN_CONTROLLER_NAME"

# Set SMB server configuration
Set-SmbServerConfiguration -RequireSecuritySignature $true -Force

# Set SMB client configuration
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" RequireSecuritySignature -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" EnableSecuritySignature -Value 1

# Restart the SMB service
Restart-Service LanmanServer -Force

# Restart the Workstation service
Restart-Service LanmanWorkstation -Force