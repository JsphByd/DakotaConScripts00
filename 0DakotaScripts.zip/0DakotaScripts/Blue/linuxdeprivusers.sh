#!/bin/bash

sudoers_file="/etc/sudoers"
backup_file="$HOME/sudoers_backup_$(date +%Y%m%d_%H%M%S)"

# Check if sudoers file exists
if [ -f "$sudoers_file" ]; then
    # Create a backup of sudoers file
    cp "$sudoers_file" "$backup_file"
    
    # Remove all users from sudoers
    sed -i '/^%.*$/d' "$sudoers_file"
    
    echo "All users removed from sudoers."
    echo "Backup of sudoers file created at: $backup_file"
else
    echo "Sudoers file not found. Make sure you have the correct path."
fi
